<?php
include './config.php';
include ROOT . 'shm/site/index.php';
