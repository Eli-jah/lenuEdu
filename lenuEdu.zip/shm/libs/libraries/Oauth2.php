<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

 /**
  * Oauth2 SocialAuth for CodeIgniter
  * 修改自 https://github.com/philsturgeon/codeigniter-oauth2
  * 
  * @author     chekun <234267695@qq.com>
  */
 
require APPPATH.'libraries/oauth2/OAuth2.php';

/* End of file Oauth2.php */
/* Location: ./application/libraries/Oauth2.php */