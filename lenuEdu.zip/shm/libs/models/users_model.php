<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class users_model extends MY_Model
{
    protected $table = 'users';
}
