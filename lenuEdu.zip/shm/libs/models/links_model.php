<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Links_model extends MY_Model
{
    protected $table = 'links';

    // public function status_show($id,$show=0){
    // 	$data = array('show'=>$show);
    // 	$where = array('id'=>$id);
    // 	$query = $this->db->update('links', $data,$where);
    // 	return $this->db->affected_rows();
    // }
}

/* End of file links_model.php */
/* Location: .//home/http/shmms/adminer/models/links_model.php */
