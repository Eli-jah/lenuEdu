<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class webmodels_model extends MY_Model
{
    protected $table = 'webmodels';
}
