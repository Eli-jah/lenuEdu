<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Modules_Model extends MY_Model
{
    protected $table = 'modules';
}

/* End of file modules_model.php */
