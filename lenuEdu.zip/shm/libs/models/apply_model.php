<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class apply_model extends MY_Model
{
    protected $table = 'recruit_apply';
}
