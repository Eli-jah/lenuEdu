<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Product_type_model extends MY_Model
{
    protected $table = 'product_type';
}
