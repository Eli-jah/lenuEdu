<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['msgs_level'][1] = 'notie'; 	// notie
$config['msgs_level'][2] = 'info';		// info
$config['msgs_level'][3] = 'success';	// success
$config['msgs_level'][4] = 'error'; 	// error
