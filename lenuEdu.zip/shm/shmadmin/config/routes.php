<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = "welcome";
$route['404_override'] = '';

// $route['module/(:)/(:num)'] = '$1/index/$2';
// $route['^([a-z]+)/(\d+)'] = '$1/index/$2';
