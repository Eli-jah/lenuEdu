<?php defined('BASEPATH') OR exit('No direct script access allowed');
// 迁移配置
$config['migration_enabled'] = FALSE;

// 迁移端口
$config['migration_version'] = 0;

// 迁移路径
$config['migration_path'] = APPPATH . 'migrations/';

/* End of file migration.php */
/* Location: ./application/config/migration.php */
