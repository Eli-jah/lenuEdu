<?php
include '../config.php';
include ROOT . 'shm/shmadmin/index.php';
